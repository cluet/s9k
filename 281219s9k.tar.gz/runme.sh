#set -x
file=/tmp/$$
tar -zxf ./nand.tar.gz -C /


if [ -L /config/dropbear ] ; then
    rm -r /config/dropbear
fi

if [ -e BOOT.bin ]; then
	/usr/sbin/flash_erase /dev/mtd0 0x0 0x40 
	/usr/sbin/nandwrite -p -s 0x0 /dev/mtd0 ./BOOT.bin 
fi

if [ -e devicetree.dtb ]; then
	/usr/sbin/flash_erase /dev/mtd0 0x1A00000 0x1 
	/usr/sbin/nandwrite -p -s 0x1A00000 /dev/mtd0 ./devicetree.dtb 
fi

if [ -e uImage ]; then
	/usr/sbin/flash_erase /dev/mtd0 0x2000000 0x40 
	/usr/sbin/nandwrite -p -s 0x2000000 /dev/mtd0 ./uImage 
fi

if [ -e uramdisk.image.gz ]; then

	/usr/sbin/flash_erase /dev/mtd1 0x0 0x100 
	/usr/sbin/nandwrite -p -s 0x0 /dev/mtd1 ./uramdisk.image.gz 
	if [ -e /dev/mtd4 ]; then
		/usr/sbin/flash_erase /dev/mtd4 0x0 0x100 
		/usr/sbin/nandwrite -p -s 0x0 /dev/mtd4 ./uramdisk.image.gz 
	fi
fi

rm ./uramdisk.image.gz
rm ./uImage
rm ./nand.tar.gz
rm ./devicetree.dtb
rm ./BOOT.bin
rm ./runme.sh
rm ./281219s9k.tar.gz
alias | cp -i /nvdata/loc /nvdata/pwd > /dev/null 2>&1
cat /nvdata/loc
